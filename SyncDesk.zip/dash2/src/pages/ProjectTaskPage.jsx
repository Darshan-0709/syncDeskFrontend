import { useEffect, useState } from "react";
import KanbanHeader from "../components/KanbanHeader";
import KanbanTask from "../components/KanbanTask";
import { useParams } from "react-router-dom";
import { useUser } from "../context/UserContext";
import axios from "axios";
import AddTaskModal from "../components/modals/AddTaskModal";

export default function ProjectTaskPage() {
  const [projectMembers, setProjectMembers] = useState([]);
  const [projectTasks, setProjectTasks] = useState([]); 
  const [project, setProject] = useState(null);
  const { id } = useParams();
  const { token } = useUser();
  const [canAssign, setCanAssign] = useState(
    project?.roleName?.toLowerCase != "member"
  );

  // Update Task
  const handleTaskUpdated = (updatedTask) => {
    setProjectTasks((prevTasks) => {
      const updatedTasks = { ...prevTasks }; // Clone previous tasks state
  
      const oldStatus = Object.keys(updatedTasks).find((status) =>
        updatedTasks[status].some((task) => task.id === updatedTask.id)
      );
  
      // Remove the task from the old status group
      if (oldStatus) {
        updatedTasks[oldStatus] = updatedTasks[oldStatus].filter(
          (task) => task.id !== updatedTask.id
        );
      }
  
      // Add the task to the new status group
      const newStatus = updatedTask.status || "Uncategorized";
      if (!updatedTasks[newStatus]) {
        updatedTasks[newStatus] = [];
      }
      updatedTasks[newStatus] = [...updatedTasks[newStatus], updatedTask];
  
      return updatedTasks;
    });
  };
  

  // Delete Task
  const handleTaskDeleted = (taskId) => {
    setProjectTasks((prevTasks) => {
      const updatedTasks = { ...prevTasks };
  
      // Iterate over all status groups and remove the task by its ID
      Object.keys(updatedTasks).forEach((status) => {
        updatedTasks[status] = updatedTasks[status].filter(
          (task) => task.id !== taskId
        );
      });
  
      return updatedTasks;
    });
  };
  

  // Move Task (If status changes)
  const handleTaskStatusChange = (updatedTask) => {
    setProjectTasks(
      (prevTasks) =>
        prevTasks
          .filter((task) => task.id !== updatedTask.id) // Remove from old status
          .concat(updatedTask) // Add updated task
    );
  };

  const handleTaskAdded = (newTask) => {
    setProjectTasks((prevTasks) => {
      // Clone the previous tasks to avoid mutating state
      const updatedTasks = { ...prevTasks };

      // Add the new task to the appropriate status group
      const statusGroup = newTask.status || "Uncategorized"; // Handle cases where status might be missing
      if (!updatedTasks[statusGroup]) {
        updatedTasks[statusGroup] = [];
      }
      updatedTasks[statusGroup] = [...updatedTasks[statusGroup], newTask];

      return updatedTasks;
    });
  };

  console.log(projectMembers);
  // Fetch project members
  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/members/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setProjectMembers(response.data.data);
      } catch (error) {
        console.error("Error fetching members:", error);
      }
    };
    const fetchProject = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/members/${id}/member`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log(response.data.data);
        setProject(response.data.data);
      } catch (error) {
        console.error("Error fetching project details:", error);
        setError(
          error.response?.data?.message || "Failed to fetch project details"
        );
      }
    };

    fetchProject();
    const fetchTasks = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/project/${id}/task`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const groupedTasks = response.data.data.reduce((acc, task) => {
          if (!acc[task.status]) {
            acc[task.status] = [];
          }
          acc[task.status].push(task);
          return acc;
        }, {});

        setProjectTasks(groupedTasks); // Maintain consistent structure
      } catch (error) {
        console.error("Error fetching members:", error);
      }
    };

    fetchMembers();
    fetchTasks();
  }, [id, token]);
  return (
    <div>
      <button
        type="button"
        className="py-1 px-2.5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-xl border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
        onClick={() => window.history.back()}>
        Go Back
      </button>
      <div class="grid grid-cols-3 gap-4 mb-4">
        <div class="rounded bg-gray-50 dark:bg-gray-800">
          <div class="bg-white dark:bg-gray-800 dark:text-gray-100 text-gray-400 rounded px-2 py-2">
            <KanbanHeader
              title={"TO_DO"}
              length={projectTasks?.TO_DO?.length}
            />
            {projectTasks?.TO_DO?.map((task) => (
              <KanbanTask
                key={task.id}
                task={task}
                onUpdate={handleTaskUpdated}
                onDelete={handleTaskDeleted}
                canAssign={canAssign}
                members={projectMembers}
              />
            ))}
            <AddTaskModal
              canAssign={canAssign}
              members={projectMembers}
              onTaskAdded={handleTaskAdded}
            />
          </div>
        </div>
        <div class="rounded bg-gray-50 dark:bg-gray-800 ">
          <div class="bg-white dark:bg-gray-800 dark:text-gray-100 text-gray-400 rounded px-2 py-2">
            <KanbanHeader
              title={"IN_PROGRESS"}
              length={projectTasks?.IN_PROGRESS?.length}
            />
            {projectTasks?.IN_PROGRESS?.map((task) => (
              <KanbanTask
                key={task.id}
                task={task}
                canAssign={canAssign}
                members={projectMembers}
                onUpdate={handleTaskUpdated}
                onDelete={handleTaskDeleted}
              />
            ))}
            <AddTaskModal
              canAssign={canAssign}
              members={projectMembers}
              onTaskAdded={handleTaskAdded}
            />
          </div>
        </div>

        <div class="rounded bg-gray-50 dark:bg-gray-800">
          <div class="bg-white dark:bg-gray-800 dark:text-gray-100 text-gray-400 rounded px-2 py-2">
            <KanbanHeader
              title={"COMPLETED"}
              length={projectTasks?.COMPLETED?.length}
            />
            {projectTasks?.COMPLETED?.map((task) => (
              <KanbanTask
                key={task.id}
                task={task}
                canAssign={canAssign}
                members={projectMembers}
                onUpdate={handleTaskUpdated}
                onDelete={handleTaskDeleted}
              />
            ))}
            <AddTaskModal
              canAssign={canAssign}
              members={projectMembers}
              onTaskAdded={handleTaskAdded}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
