import { useLocation, useParams } from "react-router-dom";
import DateText from "../components/DateText";
import RolePlaceHolder from "../components/RolePlaceHolder";
import EditProjectModal from "../components/modals/editProjectModal";
import { useEffect, useState } from "react";
import axios from "axios";
import { useUser } from "../context/UserContext";
import ProjectDetailHeader from "../components/ProjectDetailHeader";
import ProjectDetailBody from "../components/ProjectDetailBody";

export default function ProjectDetailPage() {
  const location = useLocation();
  const { id } = useParams(); // Assume the project ID is in the route
  const [project, setProject] = useState(location.state?.project || null);
  const { token } = useUser();
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/project/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log(response.data.data);
        setProject(response.data.data);
      } catch (error) {
        console.error("Error fetching project details:", error);
        setError(
          error.response?.data?.message || "Failed to fetch project details"
        );
      }
    };

    fetchProject();
  }, [id]);

  if (!project) {
    return <div>Error: No project data provided!</div>;
  }

  return (
    <div>
        <button
          type="button"
          className="py-1 px-2.5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-xl border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
          onClick={() => window.history.back()}>
          Go Back
        </button>
      <ProjectDetailHeader
        project={project}
        token={token}
        projectId={id}
      />
      <ProjectDetailBody project={project} />
    </div>
  );
}
