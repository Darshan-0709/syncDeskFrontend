import { useEffect, useState } from "react";
import ConversionProjectCard from "../components/ConversionProjectCard";
import { useParams } from "react-router-dom";
import { useUser } from "../context/UserContext";
import axios from "axios";
import Message from "../components/Message";
import { Button, TextInput } from "flowbite-react";

export default function ConversionProjectPage() {
  const { user } = useUser();
  const [projectMembers, setProjectMembers] = useState([]);
  const [project, setProject] = useState(null);
  const [projectTasks, setProjectTasks] = useState([]); // Initial state is an array
  const [loading, setLoading] = useState(true); // New loading state
  const [error, setError] = useState(null); // For error handling
  const { id } = useParams();
  const { token } = useUser();
  const [messages, setMessages] = useState([]);
  const [message, setMessage] = useState("");
  console.log(message);
  // Function to add a message to the state
  const addMessage = (messageContent) => {
    const newMessage = { messageContent, user };
    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages); // Update state
    localStorage.setItem("messages", JSON.stringify(updatedMessages)); // Save messages to localStorage
    setMessage(""); // Reset message input after sending
  };
  // Load messages from localStorage when the component is mounted
  useEffect(() => {
    const savedMessages = localStorage.getItem("messages");
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages)); // Parse and set messages if available
    }
  }, []);

  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/members/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setProjectMembers(response.data.data);
      } catch (error) {
        console.error("Error fetching members:", error);
      }
    };

    const fetchProject = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/members/${id}/member`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setProject(response.data);
      } catch (error) {
        console.error("Error fetching project details:", error);
        setError(
          error.response?.data?.message || "Failed to fetch project details"
        );
      }
    };

    const fetchTasks = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/project/${id}/task`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const groupedTasks = response.data.data.reduce((acc, task) => {
          if (!acc[task.status]) {
            acc[task.status] = [];
          }
          acc[task.status].push(task);
          return acc;
        }, {});
        setProjectTasks(groupedTasks); // Maintain consistent structure
      } catch (error) {
        console.error("Error fetching tasks:", error);
      }
    };

    const fetchAllData = async () => {
      setLoading(true); // Show loading state
      try {
        await Promise.all([fetchMembers(), fetchProject(), fetchTasks()]);
      } finally {
        setLoading(false); // Hide loading state
      }
    };

    fetchAllData();
  }, [id, token]);

  if (loading) {
    return <div>Loading...</div>; // Replace with a loading spinner if needed
  }
  return (
    <div>
      {" "}
      <button
        type="button"
        className="py-1 px-2.5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-xl border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
        onClick={() => window.history.back()}>
        Go Back
      </button>
      {/* <div class="grid grid-cols-3 gap-4 mb-4"></div>
       */}
      {/* Chat UI */}
      <div class="flex flex-col flex-auto h-full p-6">
        <div class="flex flex-col flex-auto flex-shrink-0 rounded-2xl bg-gray-200 dark:bg-gray-600  h-full p-4">
          <div class="flex flex-col h-full overflow-x-auto mb-4">
            <div class="flex flex-col h-full">
              <div class="grid grid-cols-12 gap-y-2">
                {messages?.map((msg, index) => (
                  <Message
                    key={index}
                    isUser={msg.user.id === user?.id}
                    messageContent={msg.messageContent}
                    user={msg.user}
                  />
                ))}
                {/* <div class="col-start-1 col-end-8 p-3 rounded-lg">
                  <div class="flex flex-row items-center">
                    <div class="flex items-center justify-center h-10 w-10 rounded-full bg-indigo-500 flex-shrink-0">
                      A
                    </div>
                    <div class="relative ml-3 text-sm bg-white py-2 px-4 shadow rounded-xl">
                      <div>
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit. Vel ipsa commodi illum saepe numquam maxime
                        asperiores voluptate sit, minima perspiciatis.
                      </div>
                    </div>
                  </div>
                </div> */}
                {/* <div class="col-start-6 col-end-13 p-3 rounded-lg">
                  <div class="flex items-center justify-start flex-row-reverse">
                    <div class="flex items-center justify-center h-10 w-10 rounded-full bg-indigo-500 flex-shrink-0">
                      A
                    </div>
                    <div class="relative mr-3 text-sm bg-indigo-100 py-2 px-4 shadow rounded-xl">
                      <div>I'm ok what about you?</div>
                    </div>
                  </div>
                </div> */}
                {/* <div class="  */}
              </div>
            </div>
          </div>
          <form
            onSubmit={(e) => {
              e.preventDefault(); // Prevent form from reloading the page
              addMessage(message);
            }}
            class="flex flex-row items-center h-16 rounded-xl bg-gray-300 dark:bg-gray-700  w-full px-4">
            <div class="flex-grow ml-4">
              <div class="relative w-full">
                <TextInput
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                />
              </div>
            </div>
            <div class="ml-4">
              <Button
                type="submit"
                class="flex items-center justify-center bg-indigo-500 hover:bg-indigo-600 rounded-xl text-white px-4 py-1 flex-shrink-0">
                <span>Send</span>
                <span class="ml-2">
                  <svg
                    class="w-4 h-4 transform rotate-45 -mt-px"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                      stroke-linecap="round"
                      stroke-linejoin="round"
                      stroke-width="2"
                      d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                  </svg>
                </span>
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
