import { createContext, useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode"; // Fixing import

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("authToken"));

  const navigate = useNavigate();

  useEffect(() => {
    if (token) {
      try {
        const decoded = jwtDecode(token);

        // Check token expiration
        if (decoded.exp * 1000 < Date.now()) {
          console.error("Token expired");
          handleLogout();
        } else {
          // If token is valid, set user info
          fetchUserInfo();
        }
      } catch (error) {
        console.error("Invalid token:", error);
        handleLogout();
      }
    } else {
      console.log("No token, redirecting to signin");
      navigate("/signin");
    }
  }, [token, navigate]); // Adding navigate to avoid ESLint warnings

  const fetchUserInfo = async () => {
    try {
      // Call your API to fetch user info based on email/ID
      const response = await fetch(`http://localhost:8080/users/me`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const userInfo = await response.json();
      setUser(userInfo.data);
    } catch (error) {
      console.error("Failed to fetch user info:", error);
      handleLogout();
    }
  };

  const handleLogin = (token, user) => {
    setToken(token);
    setUser(user);
    localStorage.setItem("authToken", token); // Saving token in localStorage
    navigate("/"); // Redirect to dashboard after login
  };

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("authToken");
    navigate("/signin");
  };

  return (
    <UserContext.Provider value={{ user, token, handleLogin, handleLogout }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
