import { Outlet } from "react-router-dom";

const AuthLayout = () => (
  <div>
    {/* Content area */}
    <Outlet />
  </div>
);

export default AuthLayout;
