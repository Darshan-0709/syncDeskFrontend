import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AuthLayout from "./layouts/AuthLayout";
import DashboardLayout from "./layouts/DashboardLayout";
import DashboardPage from "./pages/DashboardPage";
import SignupPage from "./pages/SignupPage";
import SigninPage from "./pages/SigninPage";
import ProtectedRoute from "./components/ProtectedRoute";
import ProjectPage from "./pages/ProjectPage";
import ProjectDetailPage from "./pages/ProjectDetailPage";
import ProjectTaskPage from "./pages/ProjectTaskPage";
import KanbanPage from "./pages/KanbanPage";
import ConversionPage from "./pages/ConversionPage";
import ConversionProjectPage from "./pages/ConversionProjectPage";

function App() {
  return (
    <Routes>
      {/* Auth Routes */}
      <Route element={<AuthLayout />}>
        <Route
          path="/signup"
          element={<SignupPage />}
        />
        <Route
          path="/signin"
          element={<SigninPage />}
        />
      </Route>

      {/* Protected Dashboard Routes */}
      <Route element={<ProtectedRoute />}>
        <Route element={<DashboardLayout />}>
          <Route
            path="/"
            element={<DashboardPage />}
          />
          <Route
            path="/signup"
            element={<SignupPage />}
          />
          <Route
            path="/projects"
            element={<ProjectPage />}></Route>
          <Route
            path="/projects/:id"
            element={<ProjectDetailPage />}
          />
          <Route
            path="/projects/:id/tasks"
            element={<ProjectTaskPage />}
          />
          <Route
            path="/kanban"
            element={<KanbanPage />}
          />
          <Route
            path="/conversion"
            element={<ConversionPage />}
          />
          <Route
            path="/conversion/:id"
            element={<ConversionProjectPage />}
          />
        </Route>
      </Route>
    </Routes>
  );
}

export default App;
