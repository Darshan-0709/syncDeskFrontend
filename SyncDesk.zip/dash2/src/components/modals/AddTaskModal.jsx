import { useEffect, useState } from "react";
import { Button, Datepicker, Label, Modal, Select } from "flowbite-react";
import { useUser } from "../../context/UserContext";
import { useParams } from "react-router-dom";
import axios from "axios";

export default function AddTaskModal({
  canAssign = false,
  members,
  onTaskAdded,
}) {
  const { user } = useUser();
  const [openModal, setOpenModal] = useState(false);
  const [errors, setErrors] = useState({});
  const { id } = useParams();
  const { token } = useUser();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    assignedTo: canAssign ? "" : user?.fullName,
    priority: "",
    status: "",
    dueDate: "",
  });
  const handleChange = (e) => {
    if (e instanceof Date) {
      setFormData({
        ...formData,
        dueDate: e, // Specifically handle Datepicker changes
      });
    } else {
      const { name, value } = e.target;
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name) {
      newErrors.name = "Task name is required.";
    }
    if (
      !formData.priority ||
      !["LOW", "MEDIUM", "HIGH"].includes(formData.priority)
    ) {
      newErrors.priority = "Priority must be LOW, MEDIUM, or HIGH.";
    }
    if (
      !formData.status ||
      !["TO_DO", "IN_PROGRESS", "COMPLETED"].includes(formData.status)
    ) {
      newErrors.status = "Status must be TO_DO, IN_PROGRESS, or COMPLETED.";
    }
    if (!formData.dueDate) {
      newErrors.dueDate = "Due date is required.";
    }

    setErrors(newErrors);
    console.log(errors);
    return Object.keys(newErrors).length === 0;
  };

  useEffect(() => {
    // console.log("formData updated:", formData);
    console.log(formData.assignedTo)
  }, [formData]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }

    try {
      const response = await axios.post(
        `http://localhost:8080/project/${id}/task`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include JWT token in the request
          },
        }
      );
      // Handle success response
      alert("Task added successfully");
      console.log(response.data.data);
      const newTask = await response.data.data;
      onTaskAdded(newTask);
      setOpenModal(false);
    } catch (error) {
      // Handle error response
      console.log(error);
      if (error.response && error.response) {
        setErrors(error.response.data); // Assuming API returns validation errors
      } else {
        setErrors({ general: "An error occurred. Please try again." });
      }
    }
  };
  const handleClose = () => {};

  return (
    <>
      <button
        onClick={() => setOpenModal(true)}
        class="flex flex-row items-center text-gray-300 mt-2 px-1 ">
        <span class="rounded mr-2 text-2xl">+</span>
        <sapn class="pt-1 rounded text-sm">New</sapn>
      </button>

      <Modal
        show={openModal}
        size="sm"
        className=""
        onClose={() => setOpenModal(false)}>
        <form
          action=""
          onSubmit={handleSubmit}>
          <div className="relative w-full max-w-md max-h-full">
            <div className="relative bg-white rounded-lg shadow dark:bg-gray-800">
              <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3 className="text-xl font-medium text-gray-900 dark:text-white">
                  Add Task
                </h3>
                <button
                  type="button"
                  className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                  onClick={() => {
                    setOpenModal(false);
                    console.log(openModal);
                  }}>
                  <svg
                    className="w-3 h-3"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14">
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    />
                  </svg>
                  <span className="sr-only">Close modal</span>
                </button>
              </div>
              <div className="p-4 md:p-5 space-y-4">
                {/* project name */}
                <div>
                  <label
                    htmlFor="name"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Task name
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Task name"
                    required=""
                    value={formData.name}
                    onChange={handleChange}
                  />
                  {errors.name && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.name}
                    </p>
                  )}
                </div>
                {/* description */}
                <div>
                  <label
                    htmlFor="description"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Description
                  </label>
                  <input
                    type="text"
                    name="description"
                    id="description"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="description"
                    required=""
                    value={formData.description}
                    onChange={handleChange}
                  />
                  {/* {errors && errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )} */}
                </div>
                <div className="max-w-md">
                  <div className="mb-2 block">
                    <Label
                      htmlFor="priority"
                      value="Select priority"
                    />
                  </div>
                  <Select
                    id="priority"
                    name="priority"
                    value={formData.priority || ""}
                    onChange={handleChange} // Update formData when the value changes
                    required>
                    <option value="">Select Priority</option>
                    <option value="LOW">LOW</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="HIGH">HIGH</option>
                  </Select>
                  {errors && errors.priority && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.priority}
                    </p>
                  )}

                  {errors && errors.priority && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.priority}
                    </p>
                  )}
                </div>
                {canAssign && (
                  <div className="max-w-md">
                    <div className="mb-2 block">
                      <Label
                        htmlFor="assignedTo"
                        value="assignedTo"
                      />
                    </div>
                    <Select
                      id="assignedTo"
                      name="assignedTo"
                      value={formData.assignedTo}
                      onChange={handleChange}>
                      <option value="">Assign To</option>

                      {members &&
                        members.map((member) => (
                          <option value={member.id}>
                            {member.user.fullName}
                          </option>
                        ))}
                    </Select>
                    {errors.assignedTo && (
                      <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                        {errors.assignedTo}
                      </p>
                    )}
                  </div>
                )}
                <div className="max-w-md">
                  <div className="mb-2 block">
                    <Label
                      htmlFor="status"
                      value="status"
                    />
                  </div>
                  <Select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}>
                    <option value="">Select status</option>

                    <option value="TO_DO">TO_DO</option>
                    <option value="IN_PROGRESS">IN_PROGRESS</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </Select>
                  {errors.status && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.status}
                    </p>
                  )}
                </div>
                <div>
                  {/* Start date */}
                  <label
                    htmlFor="due-date"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Due Date
                  </label>
                  {/* <input
                    type="date"
                    name="startDate"
                    id="startDate"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Jhon Doe"
                    required=""
                    value={formData.assignedTo}
                    onChange={handleChange}
                  /> */}
                  <Datepicker
                    minDate={new Date()}
                    name="dueDate"
                    onChange={handleChange}
                  />
                  {errors.dueDate && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.dueDate}
                    </p>
                  )}
                </div>
                {/* End date */}
                <div>
                  {/* <label
                    htmlFor="endDate"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    End Date
                  </label>
                  <input
                    type="date"
                    name="endDate"
                    id="endDate"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required=""
                    // value={projectData.endDate}
                    // onChange={handleChange}
                  /> */}
                  {/* {errors && errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )} */}
                </div>
              </div>
              <div className="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                <button
                  type="submit"
                  className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                  Create
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="customClose py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                  close
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
    </>
  );
}
