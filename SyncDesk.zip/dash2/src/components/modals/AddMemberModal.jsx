import { Modal } from "flowbite-react";
import { useState } from "react";
import { useUser } from "../../context/UserContext";
import axios from "axios";
import { useParams } from "react-router-dom";

export default function AddMemberModal() {
  const [openModal, setOpenModal] = useState(false);
  const [memberData, setMemberData] = useState({
    email: "",
    role: "Member", // Default role
  });

  const { id } = useParams();
  const [errors, setErrors] = useState({});
  const { token } = useUser(); // Get the token for authentication

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setMemberData((prevData) => ({
      ...prevData,
      [name]: value, // Dynamically update the field
    }));
  };

  const handleClose = () => {
    setMemberData({
      email: "",
      role: "Member", // Default role
    });
    setErrors({});
    setOpenModal(false);
  };

  const handleValidation = () => {
    const validationErrors = {};

    // Email validation
    if (!memberData.email.trim()) {
      validationErrors.email = "Email is required";
    } else if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(memberData.email)) {
      validationErrors.email = "Invalid email format";
    }

    // Role validation
    if (
      memberData.role.trim().toLowerCase() !== "member" &&
      memberData.role.trim().toLowerCase() !== "manager"
    ) {
      validationErrors.role = "Invalid role";
    }

    setErrors(validationErrors);
    console.log(errors);
    return Object.keys(validationErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate inputs
    if (!handleValidation()) {
      return;
    }

    try {
      // Make the PUT request to add a member
      const response = await axios.post(
        `http://localhost:8080/members/${id}`,
        memberData, // Send email and memberRole in the body
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include JWT token in the request
          },
        }
      );

      // Handle success
      console.log("Member added successfully:", response.data);
      handleClose();
      window.location.reload();
    } catch (error) {
      console.error("Error adding member:", error.response.data.message);
      setErrors({
        email: error.response?.data?.message || "Failed to add member",
      });
    }
  };
  return (
    <div>
      <button
        id="createProductButton"
        class="inline-flex items-center justify-center w-1/2 px-3 py-2 text-sm font-medium text-center text-white rounded-lg bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 sm:w-auto dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        type="button"
        onClick={() => setOpenModal(true)}
        data-drawer-target="drawer-create-product-default"
        data-drawer-show="drawer-create-product-default"
        aria-controls="drawer-create-product-default"
        data-drawer-placement="right">
        <svg
          class="w-5 h-5 mr-2 -ml-1"
          fill="currentColor"
          viewBox="0 0 20 20"
          xmlns="http://www.w3.org/2000/svg">
          <path
            fill-rule="evenodd"
            d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
            clip-rule="evenodd"></path>
        </svg>
        Add Member
      </button>
      <Modal
        show={openModal}
        size="sm"
        onClose={() => setOpenModal(false)}>
        <form
          action=""
          onSubmit={handleSubmit}>
          <div className="relative w-full max-w-md max-h-full">
            <div className="relative bg-white rounded-lg shadow dark:bg-gray-800">
              <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3 className="text-xl font-medium text-gray-900 dark:text-white">
                  Add member
                </h3>
                <button
                  type="button"
                  className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                  onClick={() => setOpenModal(false)}>
                  <svg
                    className="w-3 h-3"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14">
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    />
                  </svg>
                  <span className="sr-only">Close modal</span>
                </button>
              </div>
              <div className="p-4 md:p-5 space-y-4">
                {/* project name */}
                <div>
                  <label
                    htmlFor="member-email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Member name
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={memberData.email}
                    onChange={handleInputChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Project name"
                    required=""
                  />
                  {errors.email && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.email}
                    </p>
                  )}
                </div>
                {/* member memberRole */}
                <div>
                  <label class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Select an role
                  </label>
                  <select
                    id="role"
                    name="role"
                    value={memberData.role}
                    onChange={handleInputChange}
                    class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="Member">Member</option>
                    <option value="Manager">Manager</option>
                  </select>
                </div>
              </div>
              <div className="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                <button
                  type="submit"
                  className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                  Add member
                </button>
                <button
                  type="button"
                  onClick={handleClose}
                  className="customClose py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                  close
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
}
