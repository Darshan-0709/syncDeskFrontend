import { useUser } from "../../context/UserContext";
import { useEffect, useState } from "react";
import axios from "axios";
import { Modal } from "flowbite-react";
import { formatDate } from "../../utils/utils";

export default function EditProjectModal({ project, openModal, setOpenModal }) {
  const { token } = useUser();
  const [errors, setErrors] = useState({});

  const [editProjectData, setEditProjectData] = useState({
    name: project?.name || "",
    description: project?.description || "",
    startDate: project?.startDate || "",
    endDate: project?.endDate || "",
  });

  useEffect(() => {
    if (project?.startDate || project?.endDate) {
      const formattedStartDate = formatDate(project?.startDate);
      const formattedEndDate = formatDate(project?.endDate);

      setEditProjectData((prevData) => ({
        ...prevData,
        startDate: formattedStartDate || prevData.startDate,
        endDate: formattedEndDate || prevData.endDate,
      }));
    }
  }, [project]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditProjectData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validateDates = (startDate, endDate) => {
    const errorMessages = {};
    const start = new Date(startDate);
    const end = new Date(endDate);

    // Check if endDate is earlier than startDate
    if (startDate && endDate && end < start) {
      errorMessages.endDate = "End date cannot be earlier than start date.";
    }

    setErrors(errorMessages);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("submitting");
    validateDates(editProjectData.startDate, editProjectData.endDate);
    if (Object.keys(errors).length > 0) {
      console.log("Validation failed. Errors:", errors);
      return; // Do not proceed with the submission if there are validation errors
    }
    // console.log(project.id);

    try {
      validateDates();
      const response = await axios.put(
        `http://localhost:8080/project/${project.id}`,
        editProjectData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setOpenModal(false);
      window.location.reload();
    } catch (error) {
      console.error(error);
      if (
        error.response &&
        error.response.data &&
        error.response.data.errorCode === "VALIDATION_ERROR"
      ) {
        // Extract field-specific errors
        setErrors(error.response.data.data); // Set errors for fields
      } else {
        console.error(
          "Error updating  project:",
          error.response?.data || error.message
        );
      }
    }
  };
  const handleClose = (e) => {
    e.preventDefault();
    setEditProjectData({
      name: project?.name || "",
      description: project?.description || "",
      startDate: project?.startDate || "",
      endDate: project?.endDate || "",
    });
    setOpenModal(false);
  };
  return (
    <Modal
      show={openModal}
      size={"sm"}
      onClose={() => setOpenModal(false)}>
      <form
        action=""
        onSubmit={handleSubmit}>
        {/* <div
        id="edit-project-modal"
        tabIndex="-1"
        className="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full"> */}
        <div className="relative w-full max-w-md max-h-full">
          <div className="relative bg-white rounded-lg shadow dark:bg-gray-800">
            <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
              <h3 className="text-xl font-medium text-gray-900 dark:text-white">
                Small modal
              </h3>
              <button
                type="button"
                className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                onClick={() => setOpenModal(false)}>
                <svg
                  className="w-3 h-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 14">
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                  />
                </svg>
                <span className="sr-only">Close modal</span>
              </button>
            </div>
            <div className="p-4 md:p-5 space-y-4">
              {/* project name */}
              <div>
                <label
                  htmlFor="name"
                  className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                  Project name
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="New project"
                  required=""
                  value={editProjectData.name}
                  onChange={handleChange}
                />
                {errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )}
              </div>
              {/* description */}
              <div>
                <label
                  htmlFor="description"
                  className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                  Description
                </label>
                <input
                  type="text"
                  name="description"
                  id="description"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Short description for project"
                  required=""
                  value={editProjectData.description}
                  onChange={handleChange}
                />
                {/* {errors && errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )} */}
              </div>
              {/* Start date */}
              <div>
                <label
                  htmlFor="startDate"
                  className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                  Start Date
                </label>
                <input
                  type="date"
                  name="startDate"
                  id="startDate"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Jhon Doe"
                  required=""
                  value={editProjectData.startDate}
                  onChange={handleChange}
                />
                {errors.startDate && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.startDate}
                  </p>
                )}
              </div>
              {/* End date */}
              <div>
                <label
                  htmlFor="endDate"
                  className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                  End Date
                </label>
                <input
                  type="date"
                  name="endDate"
                  id="endDate"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  required=""
                  value={editProjectData.endDate}
                  onChange={handleChange}
                />
                {errors.endDate && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.endDate}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
              
                <button
                  type="submit"
                  onClick={() => console.log("clicked")}
                  className="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
                  Update
                </button>
              
              <button
                type="button"
                id="projectModelClose"
                onClick={handleClose}
                className="customClose py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                close
              </button>
            </div>
          </div>
        </div>
        {/* </div> */}
      </form>
    </Modal>
  );
}
