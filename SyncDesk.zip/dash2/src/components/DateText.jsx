export default function DateText({ date }) {
  return date ? (
    date.join("-")
  ) : (
    <span className="text-xs font-medium text-gray-700/55 truncate dark:text-gray-400/55">
      -- No end date provided --
    </span>
  );
}
