export default function Message({ isUser, messageContent, user }) {
  const location = isUser ? "col-start-6 col-end-13" : "col-start-1 col-end-8";
  const position = isUser
    ? "flex items-center justify-start flex-row-reverse"
    : "flex flex-row items-center";
  const margin = isUser ? "mr-3" : "ml-3";
  const background = isUser ? "bg-indigo-300" : "bg-gray-200";

  return (
    <div className={`${location} p-3 rounded-lg`}>
      <div className={`${position}`}>
        {/* Profile Icon */}
        <div className="flex items-center justify-center h-10 w-10 rounded-full bg-indigo-500 text-gray-100 flex-shrink-0">
          A
        </div>

        {/* Message Content */}
        <div
          className={`relative ${margin} text-base ${background} text-gray-800 py-2 px-4 shadow rounded-xl`}>
          <div>{messageContent}</div>
        </div>
      </div>
    </div>
  );
}
