export default function RolePlaceHolder({ role }) {
  const getColorForRole = (role) => {
    switch (role?.toLowerCase()) {
      case "admin":
        return (
          <span className="bg-green-100 text-green-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-green-900 dark:text-green-300">
            {role}
          </span>
        );
      case "manager":
        return (
          <span className="bg-yellow-100 text-yellow-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-yellow-900 dark:text-yellow-300">
            {role}
          </span>
        );
      default:
        return (
          <span className="bg-gray-100 text-gray-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-gray-700 dark:text-gray-300">
            {role}
          </span>
        ); // Default color for unknown roles
    }
  };
  return getColorForRole(role);
}
