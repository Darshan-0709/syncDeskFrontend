import { useState } from "react";
import { formatDate, formatePriority } from "../utils/utils";
import EditTaskModal from "./modals/EditTaskModal";

export default function KanbanTask({
  task,
  onUpdate,
  onDelete,
  members,
  canAssign,
}) {
  const [openModal, setOpenModal] = useState(false);

  return (
    <div class="grid gap-2 mb-2">
      <div class="p-2 shadow-sm border-gray-100 dark:border-gray-500 border-b-2">
        <div class="flex flex-row items-center mt-2 gap-2">
          <p>{formatePriority(task.priority)}</p>
          <button
            onClick={() => setOpenModal(true)}
            class="text-xs dark:text-gray-400 text-gray-600 font-medium hover:border-b-[1px]">
            {task.name}
          </button>
        </div>
        <div className="mt-3">
          <p className="text-xs text-gray-600 dark:text-gray-400 font-medium">
            Due Date:{" "}
            <span className="text-base font-md">
              {task?.dueDate ? formatDate(task?.dueDate) : "yet to set"}
            </span>
          </p>
        </div>
        <EditTaskModal
          onDelete={onDelete}
          onUpdate={onUpdate}
          task={task}
          members={members}
          canAssign={canAssign}
          openModal={openModal}
          setOpenModal={setOpenModal}
        />
      </div>
    </div>
  );
}
