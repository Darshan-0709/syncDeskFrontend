import { Link } from "react-router-dom";
import DateText from "./DateText";
import RolePlaceHolder from "./RolePlaceHolder";
import { formatDate } from "../utils/utils";

export default function ProjectCard({ project }) {
  // console.log(project);
  return (
    <div className="w-full p-4 bg-white border border-gray-200 rounded-lg shadow sm:px-8 sm:py-6  dark:bg-gray-800 dark:border-gray-700 flex gap-3 justify-between">
      <div>
        <p className="text-lg font-bold text-gray-900 truncate dark:text-gray-300">
          {project?.name}
        </p>
        <p className="text-md font-medium text-gray-900 truncate dark:text-gray-300">
          <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
            Description:{" "}
          </span>
          {project?.description || (
            <span className="text-xs font-medium text-gray-700/55 truncate dark:text-gray-400/55">
              -- No description provided --
            </span>
          )}
        </p>
        <p>
          <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
            Your Role:{" "}
          </span>
          <RolePlaceHolder role={project?.userRole}>
            {project?.userRole}
          </RolePlaceHolder>
        </p>
      </div>
      <div>
        <p className="text-md font-medium text-gray-900 truncate dark:text-gray-300">
          <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
            Start date:{" "}
          </span>
          {formatDate(project?.startDate)}
        </p>
        <p className="text-md font-medium text-gray-900 truncate dark:text-gray-300">
          <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
            End date:{" "}
          </span>
          {formatDate(project?.endDate)}
        </p>
        <p className="flex justify-end gap-2">
          <Link
            to={`/projects/${project.id}/tasks`}
            className="hover:translate-x-2 transition-all inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
            <sapn>Open In kanban</sapn>
            <svg
              className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 14 10">
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M1 5h12m0 0L9 1m4 4L9 9"
              />
            </svg>
          </Link>
          <Link
            to={`/projects/${project.id}`}
            state={{ project }}
            className="hover:translate-x-2 transition-all inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
            <span>Open</span>
            <svg
              className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
              aria-hidden="true"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 14 10">
              <path
                stroke="currentColor"
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M1 5h12m0 0L9 1m4 4L9 9"
              />
            </svg>
          </Link>
        </p>
      </div>
    </div>
  );
}
