export default function KanbanHeader({ title, length }) {
  return (
    <div class="flex flex-row justify-between items-center mb-2 mx-1">
      <div class="flex items-center">
        <h2 class="text-sm w-max px-1 rounded mr-2 font-bold">{title}</h2>
        <p class="text-gray-400 text-sm">{length}</p>
      </div>
      <div class="flex items-center">
        <p class="mr-2 text-2xl">---</p>
        <p class="text-2xl">+</p>
      </div>
    </div>
  );
}
