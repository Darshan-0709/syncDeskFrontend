import { Table, Dropdown, Button } from "flowbite-react";
import { useState } from "react";
import { formatDate } from "../utils/utils";
import RolePlaceHolder from "./RolePlaceHolder";
import axios from "axios";
import { useUser } from "../context/UserContext";

export default function MemberRow({ member, isAdmin, updateMemberRole }) {
  const [role, setRole] = useState(member.roleName);
  const [errors, setErrors] = useState({});
  const { token } = useUser();

  const handleRoleChange = async () => {
    if (!role) {
      setErrors({ role: "Role is required" });
      return;
    }
    console.log({});
    try {
      const response = await axios.put(
        `http://localhost:8080/members/${member.projectId}`,
        {
          id: member.user.id,
          role: role,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const updatedRole = response.data.data.roleName;
      setRole(updatedRole);
      updateMemberRole(member.id, updatedRole); // Notify parent
      setErrors({});
      // window.location.reload();
      console.log("reload");
    } catch (error) {
      console.error("Error updating role:", error);
      setErrors({
        role: error.response?.data?.message || "Failed to update role",
      });
    }
  };

  return (
    <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
      <Table.Cell className="whitespace-nowrap font-medium text-gray-900 dark:text-white">
        {member.user.fullName}
      </Table.Cell>
      <Table.Cell>{member.user.email}</Table.Cell>
      <Table.Cell>{formatDate(member.joinedAt)}</Table.Cell>
      <Table.Cell>
        {isAdmin && role.toLowerCase() !== "admin" ? (
          <Dropdown
            label=""
            dismissOnClick={true}
            renderTrigger={() => (
              <span>
                <RolePlaceHolder role={role} />
              </span>
            )}>
            <Dropdown.Item onClick={() => setRole("Member")}>
              <RolePlaceHolder role="Member" />
            </Dropdown.Item>
            <Dropdown.Item onClick={() => setRole("Manager")}>
              <RolePlaceHolder role="Manager" />
            </Dropdown.Item>
          </Dropdown>
        ) : (
          <RolePlaceHolder role={role} />
        )}
      </Table.Cell>
      <Table.Cell>
        {member.roleName !== role && (
          <Button
            size="xs"
            color="transparent"
            onClick={handleRoleChange}
            className="p-0 hover:bg-slate-200 dark:hover:bg-slate-500 font-medium text-cyan-600 hover:underline dark:text-cyan-500">
            Update
          </Button>
        )}
      </Table.Cell>
    </Table.Row>
  );
}
