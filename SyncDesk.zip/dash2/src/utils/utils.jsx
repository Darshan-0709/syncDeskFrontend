import { Badge } from "flowbite-react";

export const formatDate = (dateArray) => {
  if (!dateArray) return null;
  return `${dateArray[0]}-${String(dateArray[1]).padStart(2, "0")}-${String(dateArray[2]).padStart(2, "0")}`;
};

export const formatePriority = (priority) => {
  switch (priority) {
    case "HIGH":
      return <Badge color="failure">{priority}</Badge>;
    case "MEDIUM":
      return <Badge color="warning">{priority}</Badge>;
    case "LOW":
      return <Badge color="success">{priority}</Badge>;
  }
};
