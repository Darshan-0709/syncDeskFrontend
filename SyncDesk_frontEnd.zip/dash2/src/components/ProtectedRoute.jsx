import { Navigate, Outlet } from "react-router-dom";
import { useUser } from "../context/UserContext";

const ProtectedRoute = () => {
  const { token } = useUser();

  return token ? <Outlet /> : <Navigate to="/signin" />;
};

export default ProtectedRoute;
