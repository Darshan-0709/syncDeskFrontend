import { useState } from "react";
import RolePlaceHolder from "./RolePlaceHolder";
import DateText from "./DateText";
import EditProjectModal from "./modals/editProjectModal";
import { formatDate } from "../utils/utils";

export default function ProjectDetailHeader({ project }) {
  // console.log("project",project);
  const [openModal, setOpenModal] = useState(false);
  return (
    <div className="text-ms border-b-2 dark:border-gray-100 border-gray-900  px-3 pb-6 relative">
      <h1 className="text-xl font-semibold text-gray-900 sm:text-2xl dark:text-white">
        {project?.name}
      </h1>
      {/* <h1>Project Detail: {project.name}</h1> */}
      <p className="text-md font-medium text-gray-900 truncate dark:text-gray-300">
        <span className="font-medium text-gray-700 truncate dark:text-gray-400">
          Description:{" "}
        </span>
        {project?.description || (
          <span className="text-sm font-medium text-gray-700/55 truncate dark:text-gray-400/55">
            -- No description provided --
          </span>
        )}
      </p>
      <p>
        <span className="font-medium text-gray-700 truncate dark:text-gray-400">
          Your Role:{" "}
        </span>
        <RolePlaceHolder role={project?.userRole}>
          {project?.userRole}
        </RolePlaceHolder>
      </p>
      <p className="font-medium text-gray-900 truncate dark:text-gray-300">
        <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
          Start date:{" "}
        </span>
        {formatDate(project?.startDate)}
      </p>
      <p className="font-medium text-gray-900 truncate dark:text-gray-300">
        <span className="text-sm font-medium text-gray-700 truncate dark:text-gray-400">
          End date:{" "}
        </span>
        {formatDate(project?.endDate)}
      </p>
      {(project?.userRole?.toLowerCase() == "admin" ||
        project?.userRole?.toLowerCase() == "manager") && (
        <button
          onClick={() => setOpenModal(true)}
          type="button"
          className="text-white  bg-green-700 hover:bg-green-800 focus:outline-none focus:ring-4 focus:ring-green-300 font-medium rounded-xl text-md px-6 py-2 text-center me-2 mb-2 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 absolute bottom-0 right-0">
          edit
        </button>
      )}
      <EditProjectModal
        project={project}
        openModal={openModal}
        setOpenModal={setOpenModal}
      />
    </div>
  );
}
