import { useEffect, useState } from "react";
import { Button, Datepicker, Label, Modal, Select } from "flowbite-react";
import { useUser } from "../../context/UserContext";
import { useParams } from "react-router-dom";
import axios from "axios";
import { formatDate } from "../../utils/utils";

export default function EditTaskModal({
  canAssign = false,
  task,
  members,
  onUpdate,
  onDelete,
  setOpenModal,
  openModal,
}) {
  const { user } = useUser();
  const [errors, setErrors] = useState({});
  const { id } = useParams();
  const { token } = useUser();
  const [showUpdate, setShowUpdate] = useState(false);
  const [formData, setFormData] = useState({
    name: task?.name || "",
    description: task?.description || "",
    assignedTo: task?.assignedTo?.id || (!canAssign ? user?.id : ""),
    priority: task?.priority || "",
    status: task?.status || "",
    dueDate: (task?.dueDate && formatDate(task?.dueDate)) || "",
  });

  const [modalDataForm, setModalDataForm] = useState({ ...formData });
  const compareData = (current, original) => {
    return JSON.stringify(current) !== JSON.stringify(original);
  };

  useEffect(() => {
    setFormData({
      name: task?.name || "",
      description: task?.description || "",
      assignedTo: task?.assignedTo?.id || (!canAssign ? user?.id : ""),
      priority: task?.priority || "",
      status: task?.status || "",
      dueDate: (task?.dueDate && formatDate(task?.dueDate)) || "",
    });
    console.log("formdata", formData)
  }, []);

  useEffect(() => {
    console.log(formData.name);
    console.log(modalDataForm.name);
    const hasChanges = compareData(formData, modalDataForm);
    setShowUpdate(hasChanges);
  }, [formData, modalDataForm]);

  const handleChange = (e) => {
    if (e instanceof Date) {
      setFormData({
        ...formData,
        dueDate: e,
      });
    } else {
      const { name, value } = e.target;
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name) {
      newErrors.name = "Task name is required.";
    }
    if (
      !formData.priority ||
      !["LOW", "MEDIUM", "HIGH"].includes(formData.priority)
    ) {
      newErrors.priority = "Priority must be LOW, MEDIUM, or HIGH.";
    }
    if (
      !formData.status ||
      !["TO_DO", "IN_PROGRESS", "COMPLETED"].includes(formData.status)
    ) {
      newErrors.status = "Status must be TO_DO, IN_PROGRESS, or COMPLETED.";
    }
    if (!formData.dueDate) {
      newErrors.dueDate = "Due date is required.";
    }

    setErrors(newErrors);
    console.log(errors);
    return Object.keys(newErrors).length === 0;
  };

  // useEffect(() => {
  //   console.log("formData updated:", formData);
  // }, [formData]);

  const handleDelete = async (e, taskId) => {
    e.preventDefault();
    console.log(taskId);
    try {
      const response = await axios.delete(
        `http://localhost:8080/project/${id}/task/${taskId}`, // Correct URL
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Handle success response
      alert("Task deleted!");
      console.log(response);
      setModalDataForm(formData);
      console.log(modalDataForm);
      onDelete(taskId); // Call the parent handler to update state
      setOpenModal(false);
    } catch (error) {
      // Handle error response
      console.error("Error deleting task:", error);
      if (error.response && error.response.data) {
        setErrors(error.response.data); // Assuming API returns validation errors
      } else {
        setErrors({ general: "An error occurred. Please try again." });
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    console.log("requestData:");
    console.log(formData);

    try {
      const response = await axios.put(
        `http://localhost:8080/project/${id}/task/${task.id}`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`, // Include JWT token in the request
          },
        }
      );
      // Handle success response
      alert("Task Updated successfully");
      console.log(response.data.data);
      const newTask = await response.data.data;

      onUpdate(newTask);
      setOpenModal(false);
    } catch (error) {
      // Handle error response
      console.log(error);
      if (error.response && error.response) {
        setErrors(error.response.data); // Assuming API returns validation errors
      } else {
        setErrors({ general: "An error occurred. Please try again." });
      }
    }
  };
  const handleClose = () => {};

  return (
    <>
      <button
        onClick={() => setOpenModal(true)}
        class="flex flex-row items-center text-gray-300 mt-2 px-1 ">
        <svg
          className="w-6 h-6 text-gray-800 dark:text-white"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          fill="none"
          viewBox="0 0 24 24">
          <path
            stroke="currentColor"
            strokeWidth="2"
            d="M21 12c0 1.2-4.03 6-9 6s-9-4.8-9-6c0-1.2 4.03-6 9-6s9 4.8 9 6Z"
          />
          <path
            stroke="currentColor"
            strokeWidth="2"
            d="M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
          />
        </svg>

        <sapn class="pt-1 rounded text-sm">Show</sapn>
      </button>

      <Modal
        show={openModal}
        size="sm"
        className=""
        onClose={() => setOpenModal(false)}>
        <form
          action=""
          onSubmit={handleSubmit}>
          <div className="relative w-full max-w-md max-h-full">
            <div className="relative bg-white rounded-lg shadow dark:bg-gray-800">
              <div className="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                <h3 className="text-xl font-medium text-gray-900 dark:text-white">
                  Edit Task
                </h3>
                <button
                  type="button"
                  className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                  onClick={() => {
                    setOpenModal(false);
                    console.log(openModal);
                  }}>
                  <svg
                    className="w-3 h-3"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14">
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    />
                  </svg>
                  <span className="sr-only">Close modal</span>
                </button>
              </div>
              <div className="p-4 md:p-5 space-y-4">
                {/* project name */}
                <div>
                  <label
                    htmlFor="name"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Task name
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Task name"
                    required=""
                    value={formData.name}
                    onChange={handleChange}
                  />
                  {errors.name && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.name}
                    </p>
                  )}
                </div>
                {/* description */}
                <div>
                  <label
                    htmlFor="description"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Description
                  </label>
                  <input
                    type="text"
                    name="description"
                    id="description"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="description"
                    required=""
                    value={formData.description}
                    onChange={handleChange}
                  />
                  {/* {errors && errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )} */}
                </div>
                <div className="max-w-md">
                  <div className="mb-2 block">
                    <Label
                      htmlFor="priority"
                      value="Select priority"
                    />
                  </div>
                  <Select
                    id="priority"
                    name="priority"
                    value={formData.priority || ""}
                    onChange={handleChange} // Update formData when the value changes
                    required>
                    <option value="">Select Priority</option>
                    <option value="LOW">LOW</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="HIGH">HIGH</option>
                  </Select>
                  {errors && errors.priority && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.priority}
                    </p>
                  )}

                  {errors && errors.priority && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.priority}
                    </p>
                  )}
                </div>
                {canAssign && (
                  <div className="max-w-md">
                    <div className="mb-2 block">
                      <Label
                        htmlFor="assignedTo"
                        value="assignedTo"
                      />
                    </div>
                    <Select
                      id="assignedTo"
                      name="assignedTo"
                      value={formData.assignedTo}
                      onChange={handleChange}>
                      <option value="">Assign To</option>

                      {members &&
                        members.map((member) => (
                          <option value={member.id}>
                            {member.user.fullName}
                          </option>
                        ))}
                    </Select>
                    {errors.assignedTo && (
                      <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                        {errors.assignedTo}
                      </p>
                    )}
                  </div>
                )}
                <div className="max-w-md">
                  <div className="mb-2 block">
                    <Label
                      htmlFor="status"
                      value="status"
                    />
                  </div>
                  <Select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleChange}>
                    <option value="">Select status</option>

                    <option value="TO_DO">TO_DO</option>
                    <option value="IN_PROGRESS">IN_PROGRESS</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </Select>
                  {errors.status && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.status}
                    </p>
                  )}
                </div>
                <div>
                  {/* Start date */}
                  <label
                    htmlFor="due-date"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    Due Date
                  </label>
                  {/* <input
                    type="date"
                    name="startDate"
                    id="startDate"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Jhon Doe"
                    required=""
                    value={formData.assignedTo}
                    onChange={handleChange}
                  /> */}
                  <Datepicker
                    minDate={new Date()}
                    name="dueDate"
                    onChange={handleChange}
                  />
                  {errors.dueDate && (
                    <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                      {errors.dueDate}
                    </p>
                  )}
                </div>
                {/* End date */}
                <div>
                  {/* <label
                    htmlFor="endDate"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">
                    End Date
                  </label>
                  <input
                    type="date"
                    name="endDate"
                    id="endDate"
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    required=""
                    // value={projectData.endDate}
                    // onChange={handleChange}
                  /> */}
                  {/* {errors && errors.name && (
                  <p className="mt-2 text-sm text-red-600 dark:text-red-500 font-medium">
                    {errors.name}
                  </p>
                )} */}
                </div>
              </div>
              <div className="flex items-center gap-2.5 p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                {showUpdate && (
                  <button
                    type="submit"
                    className="text-white bg-green-700 hover:bg-green-800 focus:ring-4 focus:outline-none focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800">
                    Update
                  </button>
                )}
                {canAssign && (
                  <button
                    onClick={(e) => handleDelete(e, task.id)}
                    className="text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800">
                    Delete
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleClose}
                  className="customClose py-2.5 px-5 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700">
                  close
                </button>
              </div>
            </div>
          </div>
        </form>
      </Modal>
    </>
  );
}
