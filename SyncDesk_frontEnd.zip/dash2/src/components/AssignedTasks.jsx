import React from "react";
import { useUser } from "../context/UserContext";
import { Card } from "flowbite-react";
import { Link } from "react-router-dom";

export default function AssignedTasks({ projects, projectTasks }) {
  const { user } = useUser();
  let counter = 0;

  // Helper function to get tasks assigned to the logged-in user
  const getAssignedTasks = (projectTasks, userId) => {
    const assignedTasks = {};

    // Iterate through the tasks for each project
    for (const projectId in projectTasks) {
      const tasks = projectTasks[projectId];

      // Filter tasks assigned to the logged-in user
      const tasksForUser = tasks.filter(
        (task) => task?.assignedTo?.id == userId
      );
      counter += tasksForUser.length;

      // Add tasks to the assignedTasks object under the projectId key
      if (tasksForUser.length > 0) {
        const projectName =
          projects.find((project) => project.id == projectId).name || "Unknown";
        assignedTasks[projectName] = tasksForUser;
      }
    }

    console.log(assignedTasks);
    return assignedTasks;
  };

  // Call the helper function to filter tasks
  const assignedTasks = getAssignedTasks(projectTasks, user?.id);
  // console.log(assignedTasks);

  return (
    <Card className="max-w-sm mt-3">
      <h5 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
        Your Tasks({counter})
      </h5>
      <div className="font-normal text-gray-700 dark:text-gray-400">
        {Object.keys(assignedTasks).length === 0 ? (
          <p>No tasks assigned to you.</p>
        ) : (
          Object.entries(assignedTasks).map(([project, tasks]) => {
            const projectName = project || "Unknown Project";
            return (
              <div key={project}>
                <Link
                  key={project}
                  to={`/projects/${tasks[0].projectId}/tasks`}
                  className="hover:translate-x-2 mt-2 transition-all inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800 mb-2">
                  <span>{project}</span>
                  <svg
                    className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 10">
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M1 5h12m0 0L9 1m4 4L9 9"
                    />
                  </svg>
                </Link>
                {tasks.map((task) => (
                  <h6 className="font-semibold text-gray-800 dark:text-gray-200 text-base">
                    Task:{" "}
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {task.name}
                    </span>
                  </h6>
                ))}
              </div>
            );
          })
        )}
      </div>
    </Card>
  );
}
