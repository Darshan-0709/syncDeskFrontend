import { useEffect, useState } from "react";
import { Table } from "flowbite-react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { useUser } from "../context/UserContext";
import MemberRow from "./ProjectMemberRow";

export default function ProjectMemberList({ isAdmin }) {
  const [projectMembers, setProjectMembers] = useState([]);
  const { id } = useParams();
  const { token } = useUser();

  // Fetch project members
  useEffect(() => {
    const fetchMembers = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8080/members/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setProjectMembers(response.data.data);
      } catch (error) {
        console.error("Error fetching members:", error);
      }
    };
    fetchMembers();
  }, [id, token]);

  // Update a member's role in the state
  const updateMemberRole = (memberId, newRole) => {
    setProjectMembers((prevMembers) =>
      prevMembers.map((member) =>
        member.id === memberId ? { ...member, roleName: newRole } : member
      )
    );
  };

  return (
    <div className="overflow-x-auto mt-3">
      <Table hoverable>
        <Table.Head>
          <Table.HeadCell>Name</Table.HeadCell>
          <Table.HeadCell>Email</Table.HeadCell>
          <Table.HeadCell>Joined_At</Table.HeadCell>
          <Table.HeadCell>Role</Table.HeadCell>
          <Table.HeadCell>
            <span className="sr-only">Edit</span>
          </Table.HeadCell>
        </Table.Head>
        <Table.Body className="divide-y">
          {projectMembers.map((member) => (
            <MemberRow
              key={member.id}
              member={member}
              isAdmin={isAdmin}
              updateMemberRole={updateMemberRole}
            />
          ))}
        </Table.Body>
      </Table>
    </div>
  );
}
