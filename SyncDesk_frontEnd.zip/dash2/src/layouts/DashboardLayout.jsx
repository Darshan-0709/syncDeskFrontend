import { Outlet } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import { useUser } from "../context/UserContext";

const DashboardLayout = () => {
  // const { user, handleLogout } = useUser();
  return (
    <div className="text-gray-500 bg-gray-100 dark:text-gray-400 dark:bg-gray-900">
      <Navbar />
      <Sidebar />
      <main className="">
        <div className="p-4 pb-0 sm:ml-64 min-h-screen overflow-y-hidden">
          <div className="p-4 pb-0 mt-14">
            <Outlet />
          </div>
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;
