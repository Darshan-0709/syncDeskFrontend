export default function AdminLayout({ children }) {
  return (
    <>
      <div>AdminLayout</div>
      <div>{children}</div>
    </>
  );
}
