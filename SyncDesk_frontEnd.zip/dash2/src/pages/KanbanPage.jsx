import { useEffect, useState } from "react";
import NewProjectModal from "../components/modals/NewProjectModal";
import ProjectCard from "../components/ProjectCard";
import { useUser } from "../context/UserContext";
import axios from "axios";

export default function KanbanPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { token } = useUser();

  // Function to fetch projects
  const fetchProjects = async () => {
    try {
      const response = await axios.get("http://localhost:8080/project", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setProjects(response.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setError("Failed to fetch projects");
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  if (error) {
    return <div>{error}</div>;
  }
  return (
    <>
      <div className="mt-5">Select Project</div>
      <div>
        {projects.length === 0 ? (
          <p>No projects found</p>
        ) : (
          <ul>
            {projects.map((project) => (
              <li
                key={project.id}
                className="mt-3">
                <ProjectCard project={project} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
