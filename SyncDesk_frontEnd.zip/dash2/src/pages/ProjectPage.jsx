import React, { useState, useEffect } from "react";
import { useUser } from "../context/UserContext";
import axios from "axios";
import ProjectCard from "../components/ProjectCard";
import NewProjectModal from "../components/modals/NewProjectModal";

export default function ProjectPage() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { token } = useUser();

  // Function to fetch projects
  const fetchProjects = async () => {
    try {
      const response = await axios.get("http://localhost:8080/project", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setProjects(response.data);
      setLoading(false);
    } catch (err) {
      console.error(err);
      setError("Failed to fetch projects");
      setLoading(false);
    }
  };

  const addProject = (newProject) => {
    setProjects((prevProjects) => [...prevProjects, newProject]);
  };
  

  useEffect(() => {
    fetchProjects();
  }, []);

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <>
      <NewProjectModal addProject={addProject} />

      <div className="mt-5">Your projects</div>
      <div>
        {projects.length === 0 ? (
          <p>No projects found</p>
        ) : (
          <ul>
            {projects.map((project) => (
              <li
                key={project.id}
                className="mt-3">
                <ProjectCard project={project} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </>
  );
}
