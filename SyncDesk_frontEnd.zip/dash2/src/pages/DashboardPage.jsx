import { useState, useEffect } from "react";
import axios from "axios";
import { useUser } from "../context/UserContext";
import { Card } from "flowbite-react";
import AssignedTasks from "../components/AssignedTasks";
import { Link } from "react-router-dom";

export default function DashboardPage() {
  const [projectTasks, setProjectTasks] = useState({}); // Tasks grouped by project ID
  const [projects, setProjects] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { user } = useUser();
  // console.log(user?.id);
  const { token } = useUser(); // Assuming the token is available
  // console.log(projectTasks);

  const fetchTasksForProject = async (projectId) => {
    try {
      const response = await axios.get(
        `http://localhost:8080/project/${projectId}/task`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Store tasks grouped by project ID
      setProjectTasks((prevState) => ({
        ...prevState,
        [projectId]: response.data.data, // Add tasks to the corresponding project ID
      }));
    } catch (error) {
      console.error(`Error fetching tasks for project ${projectId}:`, error);
    }
  };

  // Fetch Projects first, then fetch Tasks for each project
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/project`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProjects(response.data); // Assuming response is an array of projects
      } catch (error) {
        console.error("Error fetching project details:", error);
        setError(
          error.response?.data?.message || "Failed to fetch project details"
        );
      }
    };

    const fetchAllData = async () => {
      setLoading(true); // Show loading indicator
      try {
        await fetchProject();
      } finally {
        setLoading(false); // Hide loading indicator after projects are fetched
      }
    };

    // Call fetchAllData first to get the projects
    fetchAllData();
  }, [token]); // Assuming token is the dependency here

  // Once projects are fetched, fetch tasks for each project
  useEffect(() => {
    if (projects && projects.length > 0) {
      projects.forEach((project) => {
        fetchTasksForProject(project.id); // Fetch tasks for each project
      });
    }
  }, [projects, token]); // Trigger fetching tasks when projects are available

  return (
    <div>
      {loading && <div>Loading...</div>} {/* Display loading indicator */}
      {error && <div>Error: {error}</div>} {/* Display any error */}
      <div>
        <Card className="max-w-sm">
          <h5 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
            Projects ({projects?.length})
          </h5>
          <div className="font-normal text-gray-700 dark:text-gray-400 flex flex-wrap gap-3">
            {projects?.map((project) => (
              <Link
                to={`/projects/${project.id}`}
                state={{ project }}
                className="hover:translate-x-2 transition-all inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
                <span>{project?.name}</span>
                <svg
                  className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 10">
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M1 5h12m0 0L9 1m4 4L9 9"
                  />
                </svg>
              </Link>
            ))}
          </div>
        </Card>
        <AssignedTasks
          projectTasks={projectTasks}
          projects={projects}
        />
        {/* <Card className="max-w-sm mt-3">
          <h5 className="text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
            Your Tasks ({projects?.length})
          </h5>

          <div className="font-normal text-gray-700 dark:text-gray-400 flex flex-col gap-2">
            {projects?.map((project) => (
              <Link
                to={`/projects/${project.id}`}
                state={{ project }}
                className="hover:translate-x-2 transition-all inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-gray-700 rounded-lg hover:bg-gray-800 focus:ring-4 focus:outline-none focus:ring-gray-300 dark:bg-gray-600 dark:hover:bg-gray-700 dark:focus:ring-gray-800">
                <span>{project?.name}</span>
                <svg
                  className="w-3.5 h-3.5 ms-2 rtl:rotate-180"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 10">
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M1 5h12m0 0L9 1m4 4L9 9"
                  />
                </svg>
              </Link>
            ))}
          </div>
        </Card> */}
      </div>
    </div>
  );
}
