import { useEffect, useState } from "react";
import ConversionProjectCard from "../components/ConversionProjectCard";
import { useParams } from "react-router-dom";
import { useUser } from "../context/UserContext";
import axios from "axios";

export default function ConversionPage() {
  const [projectMembers, setProjectMembers] = useState([]);
  const [projectTasks, setProjectTasks] = useState([]); // Initial state is an array
  const [projects, setProjects] = useState(null);
  const [loading, setLoading] = useState(true); // New loading state
  const [error, setError] = useState(null); // For error handling
  const { id } = useParams();
  const { token } = useUser();

  const [canAssign, setCanAssign] = useState(false);
  console.log(projects);
  useEffect(() => {
    const fetchMembers = async () => {
      // try {
      //   const response = await axios.get(
      //     `http://localhost:8080/members/${id}`,
      //     {
      //       headers: {
      //         Authorization: `Bearer ${token}`,
      //       },
      //     }
      //   );
      //   setProjectMembers(response.data.data);
      // } catch (error) {
      //   console.error("Error fetching members:", error);
      // }
    };

    const fetchProject = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/project`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setProjects(response.data);
      } catch (error) {
        console.error("Error fetching project details:", error);
        setError(
          error.response?.data?.message || "Failed to fetch project details"
        );
      }
    };

    const fetchTasks = async () => {
        try {
          const response = await axios.get(
            `http://localhost:8080/project/${id}/task`,
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );
          const groupedTasks = response.data.data.reduce((acc, task) => {
            if (!acc[task.status]) {
              acc[task.status] = [];
            }
            acc[task.status].push(task);
            return acc;
          }, {});
          setProjectTasks(groupedTasks); // Maintain consistent structure
        } catch (error) {
          console.error("Error fetching tasks:", error);
        }
    };

    const fetchAllData = async () => {
      setLoading(true); // Show loading state
      try {
        await Promise.all([fetchMembers(), fetchProject(), fetchTasks()]);
      } finally {
        setLoading(false); // Hide loading state
      }
    };

    fetchAllData();
  }, [id, token]);

  if (loading) {
    return <div>Loading...</div>; // Replace with a loading spinner if needed
  }
  return (
    <div>
      {" "}
      <button
        type="button"
        className="py-1 px-2.5 me-2 mb-2 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-xl border border-gray-200 hover:bg-gray-100 hover:text-blue-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700"
        onClick={() => window.history.back()}>
        Go Back
      </button>
      <div class="grid grid-cols-3 gap-4 mb-4">
        {projects?.map((project) => (
          <ConversionProjectCard project={project} />
        ))}
      </div>
    </div>
  );
}
